<nav class="sidebar-nav">
  <style media="screen">
    li a:hover{
      background-color: #6c757d;
    }
  </style>
    <ul id="sidebarnav">
        <hr style="border: 1px solid white; margin-top: -1px;">
        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><span class="hide-menu">CSS </span></a></li>
        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><span class="hide-menu">Javascript </span></a></li>
    </ul>
</nav>
<?php /**PATH C:\Users\ccxxii\Documents\project\eone\resources\views/guest/layouts_home/sidebarnav.blade.php ENDPATH**/ ?>