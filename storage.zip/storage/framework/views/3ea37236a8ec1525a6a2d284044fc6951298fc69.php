<?php $__env->startSection('title'); ?>
  Halaman CSS Syntax
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
  <h4 class="page-title" style="color: black;">CSS Syntax</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <div class="row">
   <div class="col-md-12" style="font-size: 20px; color: black;">
     <h3 style="margin-bottom: -20px;">Sintaks CSS</h3> <br>
     Rangkaian aturan CSS terdiri dari pemilih dan blok deklarasi: <br>
     <img src="<?php echo asset('xadmin/assets/images/css_syntax.jpg'); ?>" alt=""> <br>
     Selektor menunjuk ke elemen HTML yang ingin Anda gaya.

     Blok deklarasi berisi satu atau lebih deklarasi yang dipisahkan oleh titik koma.<br>
     Setiap deklarasi menyertakan nama properti CSS dan nilai, dipisahkan oleh titik dua.<br>
     Deklarasi CSS selalu diakhiri dengan tanda titik koma, dan blok deklarasi dikelilingi oleh kurung kurawal.
     <div class="card col-md-8">
       <div class="card-body">
         <h3 style="margin-bottom: -20px;">Contoh :</h3> <br>
         Dalam contoh ini, semua elemen <xmp> <p> </xmp> akan sejajar tengah, dengan warna teks merah:<br>
         <img src="<?php echo asset('xadmin/assets/images/g1.jpg'); ?>" alt=""><br>
         Output :<br>
         <img src="<?php echo asset('xadmin/assets/images/g2.jpg'); ?>" alt="">
       </div>
     </div>
     <hr>
     <h3 style="margin-bottom: -20px;">Komentar CSS</h3><br>
     Komentar digunakan untuk menjelaskan kode, dan dapat membantu ketika Anda mengedit kode sumber <br>
     di kemudian hari.<br>
     Komentar diabaikan oleh browser.
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ccxxii\Documents\project\eone\resources\views/home/CSS/syntax.blade.php ENDPATH**/ ?>