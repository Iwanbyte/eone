<?php $__env->startSection('title'); ?>
  Halaman CSS Intro
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
  <h4 class="page-title">CSS Introduction</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <div class="row">
   <div class="col-md-12" style="font-size: 20px;">
     Apa itu CSS?
     <ul>
       <li>CSS adalah singkatan dari C ascading S tyle S heets</li>
       <li>CSS menjelaskan bagaimana elemen-elemen HTML ditampilkan di layar, kertas, atau di media lain</li>
       <li>CSS menghemat banyak pekerjaan . Itu dapat mengontrol tata letak beberapa halaman web sekaligus</li>
       <li>Lembar gaya eksternal disimpan dalam file CSS</li>
     </ul>
     <h3 style="margin-bottom: -20px;">Mengapa Menggunakan CSS?</h3> <br>
     CSS digunakan untuk menentukan gaya untuk halaman web Anda, termasuk desain, tata letak, dan variasi tampilan untuk berbagai perangkat dan ukuran layar.
     <hr>
     <br>
     <h3 style="margin-bottom: -20px;">CSS Memecahkan Masalah Besar</h3> <br>
     HTML TIDAK PERNAH dimaksudkan untuk berisi tag untuk memformat halaman web! <br>
     HTML dibuat untuk menggambarkan konten halaman web, seperti:

     <xmp><h1> Ini tajuk </h1></xmp>
     <xmp><p> Ini adalah paragraf. </p></xmp>

     Ketika tag seperti <xmp><i></xmp>, dan atribut warna ditambahkan ke spesifikasi HTML 3.2, itu memulai mimpi buruk bagi pengembang web. Pengembangan situs web besar, di mana font dan informasi warna ditambahkan ke setiap halaman, menjadi proses yang panjang dan mahal.
     <hr>
     <br>
     <h3 style="margin-bottom: -20px;">CSS Menghemat Banyak Pekerjaan!</h3> <br>
     Definisi style biasanya disimpan dalam file .css eksternal.
     Dengan file stylesheet eksternal, Anda dapat mengubah tampilan seluruh situs web dengan mengubah hanya satu file!
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('guest.layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ccxxii\Documents\project\eone\resources\views/guest/home/CSS/introduction.blade.php ENDPATH**/ ?>